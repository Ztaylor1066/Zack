﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//
//    IF you need to use the mock classes to complete Lab 4, uncomment the code inside of MockClasses
//    NOTE: this might cause naming colisions with classes you might have created in BlackjackClassLibrary. 
//
namespace MockClasses
{

    //public class Card
    //{
    //}

    //public class Deck
    //{
    //    public void Shuffle()
    //    {
    //    }

    //    public Card Deal()
    //    {
    //        return null;
    //    }

    //    public void CreateAllCards()
    //    {
    //    }
    //}

    //public class BlackjackDeck : Deck
    //{
    //}

    //public class BlackjackHand
    //{
    //    public int Score { get; set; }
    //    public bool IsDealer { get; set; }
    //    public BlackjackHand(bool isDealer = false)
    //    {
    //    }

    //    public void AddCard(Card card)
    //    {
    //    }

    //    public void Print(int x, int y)
    //    {
    //        Console.SetCursorPosition(x, y);
    //        Console.WriteLine("[nothing to draw]");
    //    }
    //}
}
