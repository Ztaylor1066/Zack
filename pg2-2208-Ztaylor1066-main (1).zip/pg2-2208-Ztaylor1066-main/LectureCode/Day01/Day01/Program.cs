﻿using System;

namespace Day01
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }

    }
}
