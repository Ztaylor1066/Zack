﻿using System;
using PG2Input;

namespace Lab3
{
    //
    //------------Lab 3 Notes-------------
    //      Add your classes to the BlackjackClassLibrary project.
    //      Add the menu code to the Main method.
    //


    //
    //------------Lab 4 Notes-------------
    //      This project and file will be reused for lab 4. 
    //      When you start working on lab 4...
    //          Add your BlackjackGame class to the FullSailCasino project.
    //          update the menu code for Play Blackjack menu option
    //

    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
